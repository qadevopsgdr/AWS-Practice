def print_name(name):
    print("Printing from help.py")
    print(name)